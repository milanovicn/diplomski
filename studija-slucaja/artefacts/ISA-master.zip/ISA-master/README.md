Projekat iz predmeta Internet softverske arhitekture

Tim 66:
Nina Milanovic, Milica Mitrovic i Mateja Kljucevic.

Implementirana aplikacija koja predstavlja centralizovani informacioni sistem apoteka preko kojeg će korisnici moći da rezervišu preparate (lekove) i zakazuju savetovanje sa farmaceutom ili dermatologom.

Za izradu projekta korisceni: Java + Spring i Angular.

Pokretanje projekta:
1. Prvo je potrebno napraviti kopiju ovog repozitorijuma sa git clone
2. Pre pokretanja projekta potrebno je imati instaliran MySQL Workbench 8.0 CE
3. Importovati projekat kao Maven project
4. Pokrenuti projekat iz IntelliJ-a koristeci main() metodu
5. U folderu ISA-Frontend instaliranje aplikacije se vrsi komandom 'npm install' u terminalu, a pokretanje aplikacije sa 'npm start'. (Visual Studio Code)

