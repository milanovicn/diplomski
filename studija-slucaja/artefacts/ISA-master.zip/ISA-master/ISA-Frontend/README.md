Front end deo aplikacije

Za pokretanje koristiti komande:

$ npm install

$ npm start
