export class Rate{
    id:number;
    patientId:number;
    ratedId:number;
    rate:number;
    ratedSubject:string;
    ratedType:string;
    reservationId:number;
}