export class Inquiry{
    id:number;
    medicineId:number;
    pharmacyId:number;
    medicineName:string;
    pharmacyName:string;
}