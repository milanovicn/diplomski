export class SearchMedicine{
    name:string;
    code:number;
    contraindications:string;
    type:string;
}