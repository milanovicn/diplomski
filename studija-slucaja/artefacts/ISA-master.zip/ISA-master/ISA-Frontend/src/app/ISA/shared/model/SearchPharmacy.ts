export class SearchPharmacy{
    name:string;
    description:string;
    address:string;
    city:string;
    rateTo:number;
    rateFrom:number;
}