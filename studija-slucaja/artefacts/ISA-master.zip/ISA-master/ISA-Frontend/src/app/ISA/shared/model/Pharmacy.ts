export class Pharmacy{
    name:string;
    descrption:string;
    adress:string;
    id:number;
    rate:number;

}