export class DermatologistVacation {
    id:number;
    pharmacyId:number;
    dermatologistId : number;
    dateFrom: Date;
    dateTo: Date;
    status :string;

}