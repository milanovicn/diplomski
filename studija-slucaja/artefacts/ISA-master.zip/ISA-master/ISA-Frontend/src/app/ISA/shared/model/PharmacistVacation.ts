export class PharmacistVacation {
    id:number;
    pharmacyId:number;
    pharmacistId : number;
    dateFrom: Date;
    dateTo: Date;
    status :string;

}