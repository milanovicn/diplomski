export class MedicinePrice {
    id:number;
    medicineId:number;
    name:string;
    pharmacyId:number;
    dateFrom: Date;
    dateTo: Date;
    price :number;
   

}