export class Actions {
    id:number;
    pharmacyId:number;
    dateFrom: Date;
    dateTo: Date;
    description :string;

}