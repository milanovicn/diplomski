export class SearchPharmacist{
    firstname:string;
    lastname:string;
    email:string;
    address:string;
    city:string;
    rateTo:number;
    rateFrom:number;
}