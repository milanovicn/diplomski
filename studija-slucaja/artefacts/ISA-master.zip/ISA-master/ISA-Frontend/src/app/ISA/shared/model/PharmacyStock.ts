export class PharmacyStock{
    id:number;
    pharmacyId:number;
    medicineId:number;
    medicineName:string;
    inStock:number;
    reserved:number;


}