export class Complaint {
    id:number;
    patientId:number;
    complaintText:string;
    complaintAnswer:string;
    patientEmail:string;
    status:string;
    complaintSubject:string;


}