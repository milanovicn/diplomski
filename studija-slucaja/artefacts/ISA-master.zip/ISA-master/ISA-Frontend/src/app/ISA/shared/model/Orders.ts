export class Orders {
    id:number;
    pharmacyId:number;
    orderStatus:string;
    pharmacyName:string
    pharmacyAdminId:number;
    deadline:Date;
}