export class Medicine{
    id:number;
    name:string;
    contraindications:string;
    code:number;
    ingredients:string;
    prescription:string;
    type:string;
    form:string;
    manufacturer:string;
}