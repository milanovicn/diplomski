export class OrderItem{
    id:number;
    orderId:number;
    quantity:number;
    medicineName:string;
    medicineId:number;
  
}