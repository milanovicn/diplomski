export class OrderOffer{
    id:number;
    supplierId:number;
    orderId:number;
    price:number;
    deliveryDate:Date;
    status:string;
}