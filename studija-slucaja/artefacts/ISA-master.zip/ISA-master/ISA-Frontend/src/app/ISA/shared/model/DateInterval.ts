export class DateInterval{
    startDate:Date;
    endDate:Date;

}