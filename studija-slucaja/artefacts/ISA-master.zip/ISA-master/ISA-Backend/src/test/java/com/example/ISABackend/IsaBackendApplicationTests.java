package com.example.ISABackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
