package com.example.ISABackend.enums;

public enum  WorkDays {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY
}
