package com.example.ISABackend.enums;

public enum AppointmentStatus {
    AVAILABLE,
    RESERVED,
    DONE,
    CANCELED,
    ENDED;
}
