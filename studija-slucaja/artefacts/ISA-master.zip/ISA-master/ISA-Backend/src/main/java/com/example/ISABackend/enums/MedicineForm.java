package com.example.ISABackend.enums;

public enum MedicineForm {
    TABLET,
    CAPSULES,
    DROPS,
    SYRUP,
    INHALERS,
    TOPICAL,

}
