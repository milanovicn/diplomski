package com.example.ISABackend.enums;

public enum UserRole {
    SYSTEM_ADMIN,
    PHARMACY_ADMIN,
    PATIENT,
    PHARMACIST,
    DERMATOLOGIST,
    SUPPLIER
}
