package com.example.ISABackend.enums;

public enum OrderOfferStatus {
    PENDING,
    ACCEPTED,
    REJECTED;
}
