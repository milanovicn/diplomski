package com.example.ISABackend.enums;

public enum MedicineType {
    ANTIBIOTIC,
    ANTIHISTAMINE,
    ANESTHETIC,
    ANALGESIC,
    ANTISEPTICS,
    DIETARY_SUPPLEMENT,
    ANTIPYRETIC;
}
