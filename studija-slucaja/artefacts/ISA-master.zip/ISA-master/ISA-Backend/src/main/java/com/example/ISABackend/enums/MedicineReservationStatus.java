package com.example.ISABackend.enums;

public enum MedicineReservationStatus {
    RESERVED,
    CANCELED,
    ENDED;
}
