package com.example.ISABackend.enums;

public enum MedicinePrescription {
    PRESCRIPTION_DRUG,
    OVER_THE_COUNTER
}
