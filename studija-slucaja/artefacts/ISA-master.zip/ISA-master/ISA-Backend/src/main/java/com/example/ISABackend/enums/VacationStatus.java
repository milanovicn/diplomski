package com.example.ISABackend.enums;

public enum VacationStatus {
    SUBMITED,
    APPROVED,
    REJECTED
}
