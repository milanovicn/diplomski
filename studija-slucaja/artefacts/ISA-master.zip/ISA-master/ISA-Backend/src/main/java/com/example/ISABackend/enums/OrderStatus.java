package com.example.ISABackend.enums;

public enum OrderStatus {
    ACTIVE,
    INACTIVE,
    DELETED;
}
