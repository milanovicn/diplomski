package com.example.ISABackend.enums;

public enum ComplaintStatus {
   CREATED,  ANSWERED;
}
