package com.example.ISABackend.enums;

public enum RatedEntity {
    MEDICINE,
    PHARMACY,
    PHARMACIST,
    DERMATOLOGIST;
}
